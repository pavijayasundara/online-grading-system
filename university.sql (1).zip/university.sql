-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 14, 2015 at 08:52 PM
-- Server version: 5.0.67
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `university`
--

-- --------------------------------------------------------

--
-- Table structure for table `course1`
--

CREATE TABLE IF NOT EXISTS `course1` (
  `Student_Index` varchar(10) NOT NULL,
  `Assignment1` int(11) NOT NULL,
  `Assignment2` int(11) NOT NULL,
  `Assignment3` int(11) NOT NULL,
  `Assignment4` int(11) NOT NULL,
  `Assignment5` int(11) NOT NULL,
  PRIMARY KEY  (`Student_Index`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course1`
--

INSERT INTO `course1` (`Student_Index`, `Assignment1`, `Assignment2`, `Assignment3`, `Assignment4`, `Assignment5`) VALUES
('s10001', 30, 40, 50, 60, 0),
('s10002', 31, 41, 51, 61, 0),
('s10003', 32, 42, 52, 62, 0),
('s10004', 33, 43, 53, 63, 0),
('s10005', 34, 66, 54, 64, 0),
('s10006', 45, 56, 45, 77, 0),
('s10007', 0, 0, 0, 0, 69);

-- --------------------------------------------------------

--
-- Table structure for table `course2`
--

CREATE TABLE IF NOT EXISTS `course2` (
  `Student_Index` varchar(10) NOT NULL,
  `Assignment1` int(11) NOT NULL,
  `Assignment2` int(11) NOT NULL,
  `Assignment3` int(11) NOT NULL,
  `Assignment4` int(11) NOT NULL,
  `Assignment5` int(11) NOT NULL,
  PRIMARY KEY  (`Student_Index`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course2`
--

INSERT INTO `course2` (`Student_Index`, `Assignment1`, `Assignment2`, `Assignment3`, `Assignment4`, `Assignment5`) VALUES
('s10001', 70, 42, 24, 63, 0),
('s10002', 71, 69, 32, 0, 0),
('s10101', 73, 0, 0, 0, 0),
('s11323', 72, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `st_index` varchar(11) NOT NULL,
  `assignment_no` varchar(11) NOT NULL,
  `marks` int(11) NOT NULL,
  `course_no` varchar(11) NOT NULL,
  PRIMARY KEY  (`st_index`,`assignment_no`,`course_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`st_index`, `assignment_no`, `marks`, `course_no`) VALUES
('s10003', '4', 62, 'Course1'),
('s10002', '4', 61, 'Course1'),
('s10001', '4', 60, 'Course1'),
('s10007', '5', 69, 'Course1'),
('s10006', '3', 45, 'Course1'),
('s10005', '3', 54, 'Course1'),
('s10004', '3', 53, 'Course1'),
('s10003', '3', 52, 'Course1'),
('s10002', '3', 51, 'Course1'),
('s10001', '3', 50, 'Course1'),
('s10007', '2', 0, 'Course1'),
('s10006', '2', 56, 'Course1'),
('s10005', '2', 66, 'Course1'),
('s10004', '2', 43, 'Course1'),
('s10003', '2', 42, 'Course1'),
('s10007', '1', 0, 'Course1'),
('s10006', '1', 45, 'Course1'),
('s10005', '1', 34, 'Course1'),
('s10004', '1', 33, 'Course1'),
('s10003', '1', 32, 'Course1'),
('s10002', '2', 41, 'Course1'),
('s10002', '1', 31, 'Course1'),
('s10001', '2', 40, 'Course1'),
('s10001', '1', 30, 'Course1'),
('s10004', '4', 63, 'Course1'),
('s10005', '4', 64, 'Course1'),
('s10006', '4', 77, 'Course1'),
('s10007', '4', 0, 'Course1'),
('s10001', '5', 0, 'Course1'),
('s10002', '5', 0, 'Course1'),
('s10003', '5', 0, 'Course1'),
('s10004', '5', 0, 'Course1'),
('s10005', '5', 0, 'Course1'),
('s10006', '5', 0, 'Course1'),
('s10002', '1', 71, 'Course2'),
('s10001', '1', 70, 'Course2'),
('s10001', '2', 42, 'Course2'),
('s10101', '1', 73, 'Course2'),
('s11323', '1', 72, 'Course2'),
('s10001', '3', 24, 'Course2'),
('s10002', '2', 69, 'Course2'),
('s10002', '3', 32, 'Course2'),
('s10001', '4', 63, 'Course2');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE IF NOT EXISTS `lecturer` (
  `userName` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`userName`, `course`) VALUES
('lecturer2', 'Course2'),
('lecturer1', 'Course1');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=139 ;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `name`, `userName`, `password`, `email`, `level`) VALUES
(120, 'lecturer2', 'lecturer2', 'lecturer2', 'lecturer2@yahoo.com', 2),
(132, 'student1', 'student1', 'student1', '', 3),
(117, 'lecturer1', 'lecturer1', 'lecturer1', 'lecturer1@yahoo.com', 2),
(116, 'Admin', 'Admin', 'Admin123', 'admin123@yahoo.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `st_index` varchar(11) NOT NULL,
  `userName` varchar(50) NOT NULL,
  PRIMARY KEY  (`st_index`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`st_index`, `userName`) VALUES
('s10001', 'student1'),
('s10005', 'type3user2');

-- --------------------------------------------------------

--
-- Table structure for table `student_courses`
--

CREATE TABLE IF NOT EXISTS `student_courses` (
  `rowId` int(11) NOT NULL auto_increment,
  `student_index` varchar(11) NOT NULL,
  `course1` int(11) NOT NULL,
  `course2` int(11) NOT NULL,
  PRIMARY KEY  (`rowId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `student_courses`
--

INSERT INTO `student_courses` (`rowId`, `student_index`, `course1`, `course2`) VALUES
(1, 's11212', 1, 0),
(2, 's11212', 0, 1),
(3, 's11212', 1, 0),
(4, 's9', 1, 0),
(5, 's10101', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `weighted_course1`
--

CREATE TABLE IF NOT EXISTS `weighted_course1` (
  `Student_Index` varchar(11) NOT NULL,
  `Assignment1` int(11) NOT NULL,
  `Assignment2` int(11) NOT NULL,
  `Assignment3` int(11) NOT NULL,
  `Assignment4` int(11) NOT NULL,
  `Assignment5` int(11) NOT NULL,
  `weights` int(11) NOT NULL,
  `weighted_tot` int(11) NOT NULL,
  `weighted_average` double NOT NULL,
  `grade` varchar(11) NOT NULL,
  PRIMARY KEY  (`Student_Index`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `weighted_course1`
--

INSERT INTO `weighted_course1` (`Student_Index`, `Assignment1`, `Assignment2`, `Assignment3`, `Assignment4`, `Assignment5`, `weights`, `weighted_tot`, `weighted_average`, `grade`) VALUES
('s10003', 32, 42, 52, 62, 0, 10, 4980, 49.8, 'C'),
('s10002', 31, 41, 51, 61, 0, 10, 4890, 48.9, 'C'),
('s10001', 30, 40, 50, 60, 0, 10, 4800, 48, 'C'),
('s10004', 33, 43, 53, 63, 0, 60, 5070, 50.7, 'C'),
('s10005', 34, 66, 54, 64, 0, 10, 5380, 53.8, 'C'),
('s10006', 45, 56, 45, 77, 0, 0, 6080, 60.8, 'C'),
('s10007', 0, 0, 0, 0, 69, 0, 690, 6.9, 'F');

-- --------------------------------------------------------

--
-- Table structure for table `weighted_course2`
--

CREATE TABLE IF NOT EXISTS `weighted_course2` (
  `Student_Index` varchar(11) NOT NULL,
  `Assignment1` int(11) NOT NULL,
  `Assignment2` int(11) NOT NULL,
  `Assignment3` int(11) NOT NULL,
  `Assignment4` int(11) NOT NULL,
  `Assignment5` int(11) NOT NULL,
  `weights` int(11) NOT NULL,
  `weighted_tot` int(11) NOT NULL,
  `weighted_average` double NOT NULL,
  `grade` varchar(11) NOT NULL,
  PRIMARY KEY  (`Student_Index`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `weighted_course2`
--

INSERT INTO `weighted_course2` (`Student_Index`, `Assignment1`, `Assignment2`, `Assignment3`, `Assignment4`, `Assignment5`, `weights`, `weighted_tot`, `weighted_average`, `grade`) VALUES
('s10001', 70, 42, 24, 63, 0, 60, 5490, 54.9, 'C'),
('s10002', 71, 69, 32, 0, 0, 10, 5270, 52.7, 'C'),
('s10101', 73, 0, 0, 0, 0, 10, 4380, 43.8, 'C'),
('s11323', 72, 0, 0, 0, 0, 10, 4320, 43.2, 'C'),
('s10004', 0, 0, 0, 0, 0, 10, 0, 0, 'F'),
('s10005', 0, 0, 0, 0, 0, 0, 0, 0, 'F'),
('s10006', 0, 0, 0, 0, 0, 0, 0, 0, 'F');
